Multi-Diskette System is made for run directly diskettes
without having to put them in the 'files' folder.

Put this DiskExtract to the 'diskdb' folder