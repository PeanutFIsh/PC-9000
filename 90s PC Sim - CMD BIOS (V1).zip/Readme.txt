90's Computer Simulator
made by PeanutFish (MattRoyal52)
================================
This simulator is not a emulator ! just a simulator.
This simulator have not real trademarks and never gonna
display real trademarks (MS-DOS, Phoenix BIOS, Energy Star etc.)

================================
1. Features
================================

Current Features :
 - .vbs (VBScript) Add-Ons support
 - .bat (Batch) Add-Ons support
 - Simulating BIOS
 - Simulating Running Time
 - Simulating Diskettes
 - Command-Line BIOS
 - Batbox Support
 - Spritebox Support
 - Changeable Virtual Diskettes
 - More P-DOS Commands (vbsaddon, etc.)


Virtual Diskettes will be included in the future Update :
 -PeanutFish DOS Install Disk
 -PeanutFish DOS Boot Disk
 -P-DOS Demo Disk
 -Wendows Demo Disk (COMPLETED)
 -Wendows Install Disk

Thanks you for reading Readme.txt

A FAQ is just under this sentence, read it if you need help

=================================
2. How to Install ?
=================================
1) Extract Files in a folder
2) Run the file "RunSim"
3) Enjoy!

=================================
3. How to install Add-Ons ?
=================================
1) Download an Add-On
2) Place the Add-On at addon folder

=================================
4. How to make Add-Ons ?
=================================
Its simple just write your batch file
(only if you know how to write in MSDOS Batch)
and install it !

=================================
5. How to install diskettes
=================================
1) Download a diskette
2) Place it at main folder
3) Rename diskette name as "diskette"
4) Type dsk in Phonics BIOS

=====================================
=====================================
Version Fran�aise
=====================================
=====================================

90's Computer Simulator
cr�e par PeanutFish (MattRoyal52)
================================
Ce simulateur n'est pas un �mulateur ! juste un simulateur.
Ce simulateur n'a pas de vraie marques et va jamais avoir
des vraies marques (MS-DOS, Phoenix BIOS, Energy Star etc.)

================================
1. Fonctionnalit�s
================================

Fonctionnalit�s actuelles :
 - Support d'Add-Ons .vbs (VBScript)
 - Support d'Add-Ons .bat (Batch)
 - Simulation de BIOS
 - Simulation du tmps d'�x�cution
 - Simulation d'une diskette d'installation de P-DOS (Pipe DOS)
 - BIOS en Ligne de commande.
 - Disquettes virtuelles changables
 - Plus de commandes P-DOS (vbsaddon, etc.)

Merci d'avoir lu Readme.txt

Une FAQ est disponible ici :

=================================
2. Comment l'installer ?
=================================
1) Extrrait les fichiers dans un dossier
2) �x�cute le fichier "RunSim"
3) Amusez-vous!

=================================
3. Comment installer des Add-Ons ?
=================================
1) T�l�charge un Add-On
2) Place l'Add-On dans le dossier addon

=================================
4. Comment cr�e-t-on un Add-On ?
=================================
C'est simple, juste �crit un fichier Batch
(Seulement si tu sais comment coder en Batch)
et Installe-le!

=================================
5. Comment installer des disquettes ?
=================================
1) T�l�charge une disquette
2) Place-l� dans le dossier principal
3) Renomme le nom original de la diquette par "diskette"
4) Tape dskk dans le Phonics BIOS