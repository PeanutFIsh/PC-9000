===========================
 WenDOS 1.0 and Wendows 95
===========================

WenDOS (C) Mattcrosoft Corporation
Wendows (C) Mattcrosoft Corporation
Pipe DOS (C) Pipe Software Inc.

Index
------
1 - Login
2 - Wendows Interface
3 - WenDOS Web Browser

==========================
1. Login
==========================

For Wendows 95 :
Wendows 95 will ask you to make a password on the
first run. Type a password and you can now use your computer

For WenDOS :
There's different sessions
root - The admin session. Use the same password than your Wendows 95 session.
guest - Open a guest session with limited