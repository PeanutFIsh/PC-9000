=================================
PHONICS PC-9000X USER MANUAL
=================================

A2 BIOSes (C) Phonics Computer Inc.
Phonics PC-9X (C) Phonics Computer Inc.
Mattcrosoft (C) Mattsoftware Co. Ltd.
2085 CPUs (C) Outel Inc.
Pipe DOS (C) Pipe Software Co. Ltd.

Phonics Computers Inc. is happy to introduce our brand new
PC-9000X.

Content Table :
---------------
1 - PC-9000X vs. PC-9000A
2 - Outel 2085
3 - How to use
4 - The Boot Maker
5 - DiskExtract System
6 - BBMenu (BaseBoot Menu)
7 - Coming Soon...

==================================
1. PC-9000X VS. PC-9000A
==================================

The brand new PC-9000A has now a enhanced debugger mode and an improved Boot file Editor. The computer now have a new installation system called "DISKEXTRACTOR". Put your DiskExtracts in the diskdb folder then boot the DiskExtractor for start the installation.

The BIOS is also updated to our new BIOS mark. The Phonics A2 BIOSes mark.

The CPU will be changed. DowSM is starting being outdated!
Outel introduces the new OUTEL 2085! A better memory and a better I/O System.

The 2085 is also usable for all your electronic systems for it's tiny size. Tiny size, huge power.

You can get a PC-9000A at https://peanutfish.github.io/PC-9000/

==================================
2. Outel 2085 Language Reference
==================================

Unfortunealy, the Outel 2085 couldn't be made for the PC-9000A
right now. You must wait for the PC-9500A.

==================================
3. How to use
==================================

[[   FOR INSTALL A DISKETTE   ]]

When you want to use a diskette, go to the 'files' folder then put your diskette files and rename
the name file to "diskette"

Example :
I have "Wendows Install.bat" and "wendows_km.vbs".
I copy and paste them on the 'files' folder then i rename "Wendows Install.bat" to "diskette.bat"

[[   P-DOS ADDONS SYSTEM   ]]

For install Add-Ons for P-DOS, just put Batch Addons on the 'addon' folder and the VBScript Addons on the 'vbsaddon'

NOTE : The P-DOS Addons Folders are stored in 'files'

==================================
4. The Boot Maker (Phonics Editor)
==================================

WANRING : USE THIS FEATURE ONLY IF YOU DON'T HAVE BOOT FILES.

The Phonics Editor will be requested to be runned by the BIOS if you don't have a boot file to run.

You have the following features on this Editor :
 - Add a Batch command
 - Add a DowSM command
 - Add a Xunil command (Not available for the moment, Xunil isn't released yet)
 - Add a Command-Line system
   - Add Custom Commands
   - Add Custom Automated DowSM Commands
   - Add Custom Xunil Commands (Not available)

==================================
5. DiskExtractor
==================================

DiskExtractor is the brand new installation system that is way more better than diskettes. But if you need to run diskettes, use the Multi-Diskette System made by the creator of the PC-9000, Matt C.

Put your DiskExtracts on the 'diskdb' folder.
Then enter the DiskExtractor name without the file extension.
Example : If your file is called "Disk.d" then enter "Disk"

This version of PC-9000 include a DiskExtract for install the
early access version of P-DOS 3.0

==================================
6. BaseBoot Menu
==================================

Made by Pipe Software, this Base Boot Menu will allow you to
run Batch addons. You can install it trought the debugger mode.

==================================
7. Coming soon...
==================================

Mattcrosoft plan a new version of their outdated OS :
MATTCROSOFT WENDOWS 95! Including Custom Application Support
and enhanced features!

REACTIONS :
Matt C. from Phonics : "Awesome! Can't wait for it!"

Mitchel Schmidt from Pipe Software : "Mattcrosoft plan so much. I don't know if it gonna worth it."

A random guy : "I guess that is pretty good"