This compact was made for testing purposes of my
operating sytems that i coded for my simulator

Please enjoy.