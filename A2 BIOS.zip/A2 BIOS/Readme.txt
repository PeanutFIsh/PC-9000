=================================
PHONICS PC-9000X USER MANUAL
=================================

Phonics Computers Inc. is happy to introduce our brand new
PC-9000X.

Content Table :
---------------
1 - PC-9000X vs. PC-9000
2 - Outel DowSM Language Reference
3 - How to use
4 - The Boot Maker

==================================
1. PC-9000X VS. PC-9000
==================================

The PC-9000X has a new BIOS with a new interface. 
However, the PC-9000 has a older CPU and a older BIOS

Now, the PC-9000X boot system include the Outel DowSM manipulation
system. Just add dowsm then put your DowSM command.

The PC-9000X has now a cleaner file system and stock files and folders
in a different folder than root (files folder).

Don't have P-DOS ? Or doesn't want it ? Not a problem! If your PC-9000 doesn't
have boot file, the BIOS will ask you if you want to use the PHONICS EDITOR for
make a custom boot file.

==================================
2. Outel DowSM Language Reference
==================================

NOTE : The DowSM Manipulation System isn't finished yet. Some
       CPU Commands are missing.


[[   VARIABLES   ]]

You have access to the following variables : a, b, c, d, e and f
We're working for more variables possibilities.

[[   COMMANDS   ]]
PS : don't put the < > on your command when you're scripting a boot file
Example : mov b 12

 - add <variable> <number>
   - Add <number> to <variable>
 - sub <variable> <number>
   - Substract <number> to <variable>
 - mov <variable> <number>
   - Set <number> to <variable>

On Batch, use %<variable>% for use it on Batch syntax
Example : echo The variable a is equal to %a%

==================================
3. How to use
==================================

[[   FOR INSTALL A DISKETTE   ]]

When you want to use a diskette, go to the 'files' folder then put your diskette files and rename
the name file to "diskette"

Example :
I have "Wendows Install.bat" and "wendows_km.vbs".
I copy and paste them on the 'files' folder then i rename "Wendows Install.bat" to "diskette.bat"

[[   P-DOS ADDONS SYSTEM   ]]

For install Add-Ons for P-DOS, just put Batch Addons on the 'addon' folder and the VBScript Addons on the 'vbsaddon'

NOTE : The P-DOS Addons Folders are stored in 'files'

==================================
4. The Boot Maker (Phonics Editor)
==================================

WANRING : USE THIS FEATURE ONLY IF YOU DON'T HAVE BOOT FILES.

The Phonics Editor will be requested to be runned by the BIOS if you don't have a boot file to run.

You have the following features on this Editor :
 - Add a Batch command
 - Add a DowSM command
 - Add a Command-Line system
   - Add Custom Commands
   - Add Custom Automated DowSM Commands
